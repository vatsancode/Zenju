# 23 Audit System

Audit logging.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
