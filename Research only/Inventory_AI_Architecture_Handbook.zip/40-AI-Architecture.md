# 40 AI Architecture

Agent architecture.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
