# 60 Background Jobs

Queues/jobs.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
