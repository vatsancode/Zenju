# 01 Product Vision

Goals, philosophy, target users.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
