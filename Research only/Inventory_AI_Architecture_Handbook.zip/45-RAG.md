# 45 RAG

Retrieval.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
