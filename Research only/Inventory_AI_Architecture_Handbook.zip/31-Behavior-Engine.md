# 31 Behavior Engine

Pattern learning.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
