# 50 Bulk Import Agent

Excel mapping.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
