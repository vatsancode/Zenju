# 24 Versioning

Entity versioning.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
