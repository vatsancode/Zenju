# 10 Backend Architecture

Layered backend architecture.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
