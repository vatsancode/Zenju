# 00 README

Overview and navigation.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
