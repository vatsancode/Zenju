# 43 Agent Memory

Session/business memory.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
