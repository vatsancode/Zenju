# 44 Tool Calling

Safe tools.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
