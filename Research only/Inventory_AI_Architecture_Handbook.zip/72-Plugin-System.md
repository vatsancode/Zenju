# 72 Plugin System

Extensibility.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
