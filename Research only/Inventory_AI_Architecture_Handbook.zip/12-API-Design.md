# 12 API Design

REST/tool interfaces, versioning.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
