# 02 Design Philosophy

Adaptive software principles.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
