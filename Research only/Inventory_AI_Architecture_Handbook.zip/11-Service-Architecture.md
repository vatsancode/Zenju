# 11 Service Architecture

Service boundaries and responsibilities.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
