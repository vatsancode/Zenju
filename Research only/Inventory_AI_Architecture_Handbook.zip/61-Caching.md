# 61 Caching

Redis strategy.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
