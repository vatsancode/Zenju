# 54 HMS Agent

Hotel workflows.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
