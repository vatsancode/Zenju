# 20 Database Philosophy

Modeling guidance.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
