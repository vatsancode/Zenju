# 21 Database Naming Conventions

Naming standards.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
