# 46 GraphRAG

Graph retrieval.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
