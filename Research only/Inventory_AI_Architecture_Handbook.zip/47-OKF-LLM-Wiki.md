# 47 OKF LLM Wiki

Knowledge organization.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
