# 30 Rules Engine

Generic rule model.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
