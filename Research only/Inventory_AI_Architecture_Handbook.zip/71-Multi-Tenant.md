# 71 Multi Tenant

Tenant isolation.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
