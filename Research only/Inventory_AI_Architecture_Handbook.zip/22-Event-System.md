# 22 Event System

Event catalog and payloads.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
