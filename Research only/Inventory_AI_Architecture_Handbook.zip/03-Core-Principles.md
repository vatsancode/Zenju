# 03 Core Principles

Events, history, services, AI layering.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
