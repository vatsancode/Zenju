# 25 Metadata

Common metadata fields.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
