# 41 Agent Orchestrator

Tool routing.

## To be expanded
- Concepts
- Data model
- Examples
- Best practices
